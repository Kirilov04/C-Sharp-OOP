﻿namespace BorderControl.Models.Interfraces
{
    public interface Identified
    {
        string Id { get; }
    }
}
